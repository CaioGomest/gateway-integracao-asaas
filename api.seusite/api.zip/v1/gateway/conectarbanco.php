<?php

$config = array(
    'db_user' => 'u112941825_justpay',
    'db_pass' => 'Lec170622$',
    'db_name' => 'u112941825_justpay'
);

?>
